"""Ethereum Module for XChainPY Clients
.. moduleauthor:: Thorchain
"""

__version__ = '0.1.0'